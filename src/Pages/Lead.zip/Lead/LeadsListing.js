import React, {useEffect, useState} from 'react'
import {Link} from 'react-router-dom';
import getApiCall from "../../Services/getApiCall";
import putApiCall from "../../Services/putApiCall";
import swal from "sweetalert";
import patchApiCall from "../../Services/patchApiCall";
import postApiCall from "../../Services/postApiCall";
import deleteApiCall from "../../Services/deleteApiCall";
import Pagination from '../../Widgets/Pagination';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
// Import React FilePond
import { FilePond, File, registerPlugin } from 'react-filepond'
import 'filepond/dist/filepond.min.css'
import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css'
import Constant from "../../Components/Constant";
import loginUser from "../../Services/loginUser";
import useGetRoleModule from '../../Services/useGetRoleModule';
let {accessToken} = loginUser();


const LeadsListing = () => {
    const [lists, setLists] = useState([]);
    const [totalPage, setTotalPage] = useState(0);
    const [page, setpage] = useState(1);
    const [searchKey, setsearchKey] = useState("");
    const [toDt, setToDt] = useState("");
    const [fromDt, setfromDt] = useState("");

    const [name, setName] = useState("")
    const [mobile, setPhone] = useState("")
    const [email, setEmail] = useState("")
    const [documentUploadShow, setDocumentUploadShow] = useState(false);
    const [files, setFiles] = useState([])
    const [permission, setPermission] = useState({})

    const handleDocumentUploadClose = () => {
        setDocumentUploadShow(false);
        setFiles([])
        getList(1,"","","")
    }

    async function getList(page,fromDate, toDate, searchKey) {
        let response = await getApiCall(`common/send-enquiry/list?pageNo=${page}&searchKey=${searchKey}&fromDate=${fromDate}&toDate=${toDate}`);
        if(response.meta.status == true){
            let total = Math.ceil(response.total/10)
            setTotalPage(total >= 1 ? total : 1)
            setpage(response.pages)
           let out = response.data.map((item, index) => {
                return <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{item.name}</td>
                    <td>{item.mobile}</td>
                    <td>{item.email}</td>
                    <td>{new Date(item.createdAt).toLocaleDateString("en-US")}</td>
                </tr>

            })
            setLists(out)
        }else{
            setLists([])
        }
        
    }

    async function GetRole(){
        let Role = await useGetRoleModule("properties");
            setPermission(Role)
            unsetInput();
            getList(1,"","","");
    }

    useEffect(() => {
        GetRole()
        
    }, []);

     // pagination handler
     const paginationHandler = (page) => {
        getList(page,"","",searchKey);
    }

    function UpdateStatus(e) {
        let id = e.currentTarget.getAttribute('value');
        let status = e.currentTarget.getAttribute('status');
        status = status === "DEACTIVE" ? "ACTIVE" : "DEACTIVE"
        patchApiCall('common/blog/changeStatus/' + id, {
            status: status,
        }).then((response) => {
            if (response.meta.status) {
                swal({text: response.meta.msg, icon: "success", dangerMode: false})
                getList();
            }
        });
    }

    function DeleteEvent(e) {
        let id = e.currentTarget.getAttribute('value');
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                deleteApiCall('common/blog/delete/' + id, {}).then((response) => {
                    if (response.meta.status) {
                        swal({text: response.meta.msg, icon: "success", dangerMode: false})
                        getList();
                    }
                });
            } else {
                // swal("Your imaginary file is safe!");
            }
        });

    }

    function unsetInput(){
        setName("")
        setPhone("")
        setEmail("")
    }

    async function addLead(){
        if(name == ""){
            alert("Name required..!!")
            return false;
        }else if(mobile == ""){
            alert("Phone required..!!")
            return false;
        }else if(email == ""){
            alert("Email required..!!")
            return false;
        }
            let response = await postApiCall("common/send-enquiry/byAdmin", {name , email, mobile}, true);
            if(response.meta.status){
                alert(response.meta.msg)
                unsetInput();
                getList(1,"","","");
            }else{
                alert(response.meta.msg)
            }
    }

    function filterHandler(){
        getList(1,toDt,fromDt,searchKey);
    }

    async function downloadExcel(){
        let response = await getApiCall(`common/send-enquiry/dropdownList?exportData=1&pageNo=${page}&searchKey=${searchKey}&fromDate=${fromDt}&toDate=${toDt}`);
        if(response.meta.status == true){
            console.log(response.data)
            var csvString = response.data;
            var universalBOM = "\uFEFF";
            var a = window.document.createElement('a');
            a.setAttribute('href', 'data:text/csv; charset=utf-8,' + encodeURIComponent(universalBOM+csvString));
            a.setAttribute('download', 'exportLeadList.csv');
            window.document.body.appendChild(a);
            a.click();
            // window.location.reload();
        }
        
    }

    return (
        <>
            <div className="container-fluid">

                <div className="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 className="h3 mb-0 text-gray-800">Leads</h1>

                </div>
                {!permission.moduleAccress ?  
              <div className="row text-center">
                   <div className="col-sm-12 col-md-6 offset-md-3 col-lg-4 offset-lg-4">
                  <div className="errer">
                  <img src="/program-error.png"/>
                      <h2>403</h2>
                        {/* <h4 className="text-danger">{permission.message}</h4> */}
                      <p>{permission.message}</p>
                         
                       </div>
                  </div>
                  </div>
              : <>
                {permission.moduleList.createDisabled ? null :
                <div className="card mb-2">
                    {/*<div className="card-header">*/}
                    {/*    <div className="cart-title">Leads</div>*/}
                    {/*</div>*/}
                    <div className="card-body">
                      
                            <div className="row">
                                <div className="col-md-2">
                                <label className="font-weight-bold">Name*</label>
                                    <div className="form-group">
                                        <input type="text" className="form-control" value={name} onChange={(e) => setName(e.target.value)}/>
                                    </div>
                                </div>
                                <div className="col-md-2">
                                <label className="font-weight-bold">Phone*</label>
                                    <div className="form-group">
                                        <input type="number" className="form-control" value={mobile}  onChange={(e) => setPhone(e.target.value)}/>
                                    </div>
                                </div>
                                <div className="col-md-2">
                                <label className="font-weight-bold">Email*</label>
                                    <div className="form-group">
                                        <input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)}/>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                <label className="font-weight-bold"></label>
                                    <div className="form-group">
                                        <button className="btn btn-primary" onClick={(e) => addLead()}>Add</button>
                                        <button className="btn btn-primary" type={"button"} style={{marginLeft: 3}} onClick={() => setDocumentUploadShow(true)}>Bulk Upload</button>
                                        
                                    </div>
                                </div>
                              
                            </div>
                     
                    </div>


                </div> }


                <div className="card shadow mb-4">
                    <div className="card-body">
                        <div className="row mb-4">
                            <div className='col col-md-6'>
                                <label className="font-weight-bold">Search By Name and Mobile number</label>
                            <div className="form-group">
                                        <input type="text" value={searchKey} className="form-control" onChange={(e) => setsearchKey(e.target.value)}/>
                                    </div>
                            </div>
                            <div className='col col-md-2'>
                            <label className="font-weight-bold">Start Date</label>
                            <div className="form-group">
                                        <input type="date" value={toDt} className="form-control" onChange={(e) => setToDt(e.target.value)}/>
                                    </div>
                            </div>
                            <div className='col col-md-2'>
                            <label className="font-weight-bold">End Date</label>
                            <div className="form-group">
                                        <input type="date" value={fromDt} className="form-control" onChange={(e) => setfromDt(e.target.value)}/>
                                    </div>
                            </div>
                            <div className='col col-md-2'>
                            <label className="font-weight-bold"></label>
                            <div className="form-group">
                                        <button className='btn btn-primary' onClick={() => filterHandler()}>Search</button>
                                        <button className="btn btn-primary " type={"button"} style={{marginLeft: 3}} onClick={() => downloadExcel()}>Download</button>
                                    </div>
                            </div>
                        </div>
                        <div className="table-responsive">
                            <table className="table table-bordered" width="100%" cellSpacing="0">
                                <thead>
                                <tr>
                                    <th>SR. No.</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    {/*<th>Action</th>*/}
                                </tr>
                                </thead>

                                <tbody>
                                 {lists}
                                </tbody>
                            </table>
                        </div>
                        <Pagination prev={page ==1 ? 1 : (page > 1) ? page-1 : page } current={page} next={page+1} pageCount={totalPage} handler={paginationHandler} />
                    </div>
                </div>
                </> }
                <Modal show={documentUploadShow} onHide={handleDocumentUploadClose} size="lg">
            <Modal.Header closeButton>
                <Modal.Title style={{fontSize: 15}}>Upload New Document</Modal.Title>
            </Modal.Header>
            <Modal.Body style={{display:'flex', flexDirection:'column'}}>
            <div style={{marginBottom: 12}}>
                 <a className="btn btn-primary btn-sm float-right" href="/lead-bulk-upload.xlsx">Download Sample</a>
            </div>

            <div className="">
      <FilePond
        files={files}
        onupdatefiles={setFiles}
        allowMultiple={true}
        maxFiles={1}
        name="excel"
        acceptedFileTypes={'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}
        labelIdle='Drag & Drop your files or <span class="filepond--label-action">Browse</span>'
        server={{
            url: Constant.apiBasePath + 'common/send-enquiry/uploadLeadExcel',
            process: {
                headers: {
                    authkey: accessToken
                },
                onload: (res) => {
                     console.log(res)
                },
            }
        }}
      />
    </div>
                </Modal.Body>
            <Modal.Footer>
            </Modal.Footer>
        </Modal>

            </div>
        </>
    )
}

export default LeadsListing
